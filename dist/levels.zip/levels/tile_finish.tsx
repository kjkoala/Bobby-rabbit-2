<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="tile_finish" tilewidth="16" tileheight="16" tilecount="4" columns="4">
 <image source="tile_finish.png" width="64" height="16"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="90"/>
   <frame tileid="1" duration="90"/>
   <frame tileid="2" duration="90"/>
   <frame tileid="3" duration="90"/>
  </animation>
 </tile>
</tileset>
